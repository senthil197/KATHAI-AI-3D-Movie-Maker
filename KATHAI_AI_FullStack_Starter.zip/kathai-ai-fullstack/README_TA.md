# KATHAI AI – Full-stack starter

இது Emergent அல்லாத தனி Node.js + Supabase starter project.

## Android மொபைலில் தொடங்குவது
இந்த ZIP-ஐ முதலில் பாதுகாப்பாக வைத்துக்கொள்ளுங்கள். Node.js இயக்கக்கூடிய hosting அல்லது online development environment தேவை. மொபைல் browser மட்டும் கொண்டு server-ஐ நேரடியாக இயக்க முடியாது.

## அமைப்பு
1. Supabase-ல் புதிய project உருவாக்கவும்.
2. SQL Editor-ல் `supabase/schema.sql` உள்ள SQL-ஐ இயக்கவும்.
3. Storage-ல் `kathai-assets` என்ற bucket உருவாக்கவும்.
4. `.env.example`-ஐ `.env` என நகலெடுத்து Supabase URL, anon key, service role key நிரப்பவும்.
5. `npm install` பின்னர் `npm start`.
6. Admin account உருவாக்கி email verify செய்த பிறகு SQL-ல் profile role-ஐ admin ஆக மாற்றவும்.

## பாதுகாப்பு
- `SUPABASE_SERVICE_ROLE_KEY`-ஐ frontend-ல் ஒருபோதும் வைக்க வேண்டாம்.
- `.env`-ஐ GitHub-க்கு upload செய்ய வேண்டாம்.
- Admin role-ஐ browser மூலம் மாற்ற முடியாது; backend profile-ஐச் சரிபார்க்கிறது.
- Admin email-ஐ project owner தானே verify செய்து SQL மூலம் promote செய்ய வேண்டும்.

## இப்போது செயல்படும் அடித்தள வசதிகள்
- Express backend மற்றும் health check
- Supabase profile/project schema
- Login session token மூலம் protected API access
- Movie project save/list
- Reference photo upload to Supabase Storage
- Backend admin role verification மற்றும் user list/credit update endpoints
- Mobile responsive dashboard UI

## இன்னும் API இணைப்பு தேவை
Image generation, video generation, Tamil TTS, lip-sync, scene orchestration, final movie rendering, promo-code redemption ஆகியவை provider-specific API இணைப்பு மற்றும் கூடுதல் implementation தேவை. இப்போது generation endpoint உண்மையான provider அமைக்கப்படாவிட்டால் தெளிவான பிழையைத் தரும்; போலியான output உருவாக்காது.
