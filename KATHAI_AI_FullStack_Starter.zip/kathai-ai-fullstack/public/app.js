let accessToken = localStorage.getItem('kathai_token') || '';
const $ = id => document.getElementById(id);
const api = async (url, options={}) => {
  const headers = {...(options.headers||{})};
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  if (!(options.body instanceof FormData) && options.body) headers['Content-Type']='application/json';
  const r = await fetch(url,{...options,headers});
  const data = await r.json().catch(()=>({error:'Unexpected server response'}));
  if (!r.ok) throw new Error(data.error || `Request failed (${r.status})`);
  return data;
};
document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>{
  document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(x=>x.classList.remove('active'));
  b.classList.add('active'); $(b.dataset.tab).classList.add('active');
}));
$('menuBtn').onclick=()=>document.querySelector('.tabs').scrollIntoView({behavior:'smooth'});
async function health(){try{const h=await api('/api/health');$('apiStatus').textContent=h.databaseConfigured?'BACKEND ONLINE · DB READY':'BACKEND ONLINE · DATABASE SETUP NEEDED';}catch(e){$('apiStatus').textContent='BACKEND CONNECTION ERROR';}}
health();
$('saveToken').onclick=()=>{accessToken=$('token').value.trim();localStorage.setItem('kathai_token',accessToken);$('accountMsg').textContent='Token saved in this browser. Keep it private.';};
$('saveProject').onclick=async()=>{
 try{const p=await api('/api/projects',{method:'POST',body:JSON.stringify({title:$('title').value,story:$('story').value,language:$('language').value,visual_style:$('style').value,target_minutes:Number($('minutes').value)})});$('projectMsg').textContent=`Project saved: ${p.title}`;}
 catch(e){$('projectMsg').textContent=e.message;}
};
$('loadProjects').onclick=async()=>{
 try{const ps=await api('/api/projects');$('projects').innerHTML='';ps.forEach(p=>{const d=document.createElement('div');d.className='project';d.textContent=p.title;const s=document.createElement('small');s.textContent=` · ${p.status} · ${p.target_minutes} min`;d.appendChild(s);$('projects').appendChild(d);});if(!ps.length)$('projects').textContent='No projects yet.';}
 catch(e){$('projects').textContent=e.message;}
};
$('photo').onchange=async()=>{
 const f=$('photo').files[0];if(!f)return;
 try{const fd=new FormData();fd.append('photo',f);const result=await api('/api/upload/reference',{method:'POST',body:fd});$('characterMsg').textContent=`Photo uploaded: ${result.url}`;}
 catch(e){$('characterMsg').textContent=e.message;}
};
document.querySelectorAll('.generation').forEach(b=>b.onclick=async()=>{
 const kind=b.dataset.kind;const target=kind==='character'?'characterMsg':kind==='location'?'locationMsg':kind==='object'?'objectMsg':'voiceMsg';
 try{await api(`/api/generate/${kind}`,{method:'POST',body:JSON.stringify({prompt:$(`${kind==='character'?'character':kind==='location'?'location':kind==='object'?'object':'voice'}Prompt`)?.value||''})});}
 catch(e){$(target).textContent=e.message;}
});
$('loadUsers').onclick=async()=>{try{$('users').textContent=JSON.stringify(await api('/api/admin/users'),null,2);}catch(e){$('users').textContent=e.message;}};
