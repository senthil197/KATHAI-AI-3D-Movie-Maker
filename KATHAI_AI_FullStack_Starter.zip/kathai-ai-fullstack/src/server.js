import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import morgan from 'morgan';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import { createClient } from '@supabase/supabase-js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
const port = process.env.PORT || 3000;

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '2mb' }));
app.use(morgan('tiny'));
app.use(express.static(path.join(__dirname, '../public')));

const configured = Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_ANON_KEY && process.env.SUPABASE_SERVICE_ROLE_KEY);
const admin = configured ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY) : null;
const anon = configured ? createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY) : null;

async function auth(req, res, next) {
  if (!configured) return res.status(503).json({ error: 'Supabase is not configured. Add the environment variables first.' });
  const token = (req.headers.authorization || '').replace(/^Bearer\\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Sign in is required.' });
  const { data, error } = await anon.auth.getUser(token);
  if (error || !data.user) return res.status(401).json({ error: 'Invalid or expired login session.' });
  req.user = data.user;
  next();
}
async function adminOnly(req, res, next) {
  const { data, error } = await admin.from('profiles').select('role').eq('id', req.user.id).single();
  if (error || data?.role !== 'admin') return res.status(403).json({ error: 'Administrator permission required.' });
  next();
}
function missingProvider(name, envName) {
  return { error: `${name} provider is not configured. Add ${envName} on the server before using this feature. No fake output was created.` };
}

app.get('/api/health', (_req, res) => res.json({
  status: 'online',
  backend: 'KATHAI AI API',
  databaseConfigured: configured,
  aiProviders: {
    image: Boolean(process.env.IMAGE_PROVIDER_URL && process.env.IMAGE_PROVIDER_API_KEY),
    video: Boolean(process.env.VIDEO_PROVIDER_URL && process.env.VIDEO_PROVIDER_API_KEY),
    voice: Boolean(process.env.TTS_PROVIDER_URL && process.env.TTS_PROVIDER_API_KEY),
    lipSync: Boolean(process.env.LIPSYNC_PROVIDER_URL && process.env.LIPSYNC_PROVIDER_API_KEY)
  }
}));

app.get('/api/me', auth, async (req, res) => {
  const { data, error } = await admin.from('profiles').select('id,email,display_name,role,plan,credits').eq('id', req.user.id).single();
  if (error) return res.status(404).json({ error: 'Profile not found. Run the Supabase SQL setup.' });
  res.json(data);
});

app.get('/api/projects', auth, async (req, res) => {
  const { data, error } = await admin.from('projects').select('*').eq('user_id', req.user.id).order('created_at', { ascending: false });
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post('/api/projects', auth, async (req, res) => {
  const { title, story, language = 'ta', visual_style = '3d-anime', target_minutes = 5 } = req.body || {};
  if (!title || !story) return res.status(400).json({ error: 'Title and story are required.' });
  const minutes = Math.max(1, Math.min(Number(target_minutes) || 5, 120));
  const { data, error } = await admin.from('projects').insert({
    user_id: req.user.id, title, story, language, visual_style, target_minutes: minutes, status: 'draft'
  }).select().single();
  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json(data);
});

app.post('/api/upload/reference', auth, upload.single('photo'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Choose a photo to upload.' });
  const bucket = process.env.SUPABASE_STORAGE_BUCKET || 'kathai-assets';
  const safeName = `${req.user.id}/${Date.now()}-${req.file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
  const { data, error } = await admin.storage.from(bucket).upload(safeName, req.file.buffer, { contentType: req.file.mimetype, upsert: false });
  if (error) return res.status(500).json({ error: error.message });
  const { data: urlData } = admin.storage.from(bucket).getPublicUrl(data.path);
  res.status(201).json({ path: data.path, url: urlData.publicUrl, note: 'Reference uploaded. Connect an image-generation provider to use it for generation.' });
});

app.post('/api/generate/:kind', auth, async (req, res) => {
  const kind = req.params.kind;
  const providers = {
    character: ['IMAGE_PROVIDER_URL', 'IMAGE_PROVIDER_API_KEY', 'image'],
    location: ['IMAGE_PROVIDER_URL', 'IMAGE_PROVIDER_API_KEY', 'image'],
    object: ['IMAGE_PROVIDER_URL', 'IMAGE_PROVIDER_API_KEY', 'image'],
    voice: ['TTS_PROVIDER_URL', 'TTS_PROVIDER_API_KEY', 'voice'],
    lipsync: ['LIPSYNC_PROVIDER_URL', 'LIPSYNC_PROVIDER_API_KEY', 'lipSync'],
    movie: ['VIDEO_PROVIDER_URL', 'VIDEO_PROVIDER_API_KEY', 'video']
  };
  if (!providers[kind]) return res.status(404).json({ error: 'Unknown generation type.' });
  const [urlKey, keyKey, label] = providers[kind];
  if (!process.env[urlKey] || !process.env[keyKey]) return res.status(503).json(missingProvider(label, `${urlKey} and ${keyKey}`));
  return res.status(501).json({ error: 'Provider credentials are present, but this provider adapter has not yet been implemented. Configure the provider-specific request format before enabling generation.' });
});

app.get('/api/admin/users', auth, adminOnly, async (_req, res) => {
  const { data, error } = await admin.from('profiles').select('id,email,display_name,role,plan,credits,created_at').order('created_at', { ascending: false });
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.post('/api/admin/credits', auth, adminOnly, async (req, res) => {
  const { user_id, credits } = req.body || {};
  if (!user_id || !Number.isInteger(credits) || credits < 0) return res.status(400).json({ error: 'Provide user_id and a non-negative integer credits value.' });
  const { data, error } = await admin.from('profiles').update({ credits }).eq('id', user_id).select('id,credits').single();
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

app.use('/api', (_req, res) => res.status(404).json({ error: 'API route not found.' }));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '../public/index.html')));
app.listen(port, () => console.log(`KATHAI AI running on port ${port}`));
