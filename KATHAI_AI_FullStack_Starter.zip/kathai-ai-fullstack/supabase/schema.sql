-- Run this in Supabase SQL Editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  role text not null default 'user' check (role in ('user','admin')),
  plan text not null default 'free',
  credits integer not null default 0 check (credits >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  story text not null,
  language text not null default 'ta',
  visual_style text not null default '3d-anime',
  target_minutes integer not null default 5 check (target_minutes between 1 and 120),
  status text not null default 'draft',
  created_at timestamptz not null default now()
);

create table if not exists public.promo_codes (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  credits integer not null default 0 check (credits >= 0),
  plan text,
  expires_at timestamptz,
  max_redemptions integer,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.promo_redemptions (
  id uuid primary key default gen_random_uuid(),
  promo_id uuid not null references public.promo_codes(id),
  user_id uuid not null references public.profiles(id),
  redeemed_at timestamptz not null default now(),
  unique(promo_id, user_id)
);

alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.promo_codes enable row level security;
alter table public.promo_redemptions enable row level security;

create policy "Users read own profile" on public.profiles for select using (auth.uid() = id);
create policy "Users read own projects" on public.projects for select using (auth.uid() = user_id);
create policy "Users create own projects" on public.projects for insert with check (auth.uid() = user_id);
-- Service-role backend performs privileged admin changes. Never expose service-role key in browser.
-- Create a private storage bucket named kathai-assets in Supabase Storage.
-- After verifying the administrator email, promote that profile manually in SQL:
-- update public.profiles set role='admin' where email='YOUR_VERIFIED_EMAIL';
